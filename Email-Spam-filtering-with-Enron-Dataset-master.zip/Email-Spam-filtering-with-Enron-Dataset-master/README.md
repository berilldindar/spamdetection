# Email-Spam-filtering-with-Enron-Dataset

This is a code for Email Spam Filtering using Enron Data Set.

Link for Data Set: https://github.com/prodicus/datasets/tree/master/email/plaintext

Video Link: https://www.youtube.com/watch?v=BikuBr6K61o&t

Slides: https://www.slideshare.net/singhlaaman/machine-learning-project-email-spam-filtering-using-enron-dataset